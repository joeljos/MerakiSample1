from config import *

traffic_analytics_configurations = [
    {
        "networkId": "L_819655132181432830",
        "timespan": '10000'
    }
]