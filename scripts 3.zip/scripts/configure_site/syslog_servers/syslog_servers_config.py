import sys
sys.path.append('../../')
from config import *

list_servers = [
    {
        "networkId": ""
    }
]

update_syslog_servers = [
    {
        "networkId": "",
        "configurations": {
            "servers": [
                {
                    "host": "1.2.3.4",
                    "port": 443,
                    "roles": [
                        "Wireless event log",
                        "URLs"
                    ]
                }
            ]
        }
    }
]