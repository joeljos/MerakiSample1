"""
Copyright (c) 2023 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

__author__ = "Lakshya Tyagi <ltyagi@cisco.com>, Trevor Maco <tmaco@cisco.com>"
__copyright__ = "Copyright (c) 2023 Cisco and/or its affiliates."
__license__ = "Cisco Sample Code License, Version 1.1"

import os
import re
import sys
import requests
import logging
from dotenv import load_dotenv
from urllib.error import HTTPError


from configure_site.syslog_servers.syslog_servers_config import *

load_dotenv()

logging.basicConfig(level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')


meraki_base_url = os.getenv("MERAKI_BASE_URL")
meraki_api_key = os.getenv("MERAKI_API_KEY")
meraki_device_serial = os.getenv("MERAKI_DEVICE_SERIAL")

#header
headers = {
    'X-Cisco-Meraki-API-Key': meraki_api_key,
    'Content-Type': 'application/json'
}


# List syslog servers for a network
# Update syslog servers for a network

def list_syslog_servers():
    """
    List syslog servers for a network
    """

    for config in list_servers:
        net_id = config["networkId"]
        try:
            response = requests.get(url = f"{meraki_base_url}/networks/{net_id}/syslogServers", headers= headers)
            if response.status_code == 200:
                syslog_serv = response.json()
                logging.info(f"Listing Syslog servers for Network ID: {net_id}")
                logging.info(syslog_serv)
        except HTTPError as http:
            logging.info(http)
        except Exception as ex:
            logging.info(ex)


def update_syslog_servers():
    """
    Update syslog servers for a network
    """

    for config in update_syslog_servers:
        net_id = config["network_id"]
        syslog_payload = config["configurations"]
        try:
            response = requests.request("PUT", url = f"{meraki_base_url}/networks/{net_id}/syslogServers", headers= headers, data=syslog_payload)
            if response.status_code == 200:
                res = response.json()
                logging.info(f"Updated syslog servers for Network: {net_id}")
        except HTTPError as http:
            logging.info(http)
        except Exception as ex:
            logging.info(ex)
