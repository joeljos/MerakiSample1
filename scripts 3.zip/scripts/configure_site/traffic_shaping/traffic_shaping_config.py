import sys
sys.path.append('../../')
from config import *

list_traffic_shaping_settings = {
    {
        "networkId": "",
        "ssid_num": ""
    }
}

update_traffic_shaping = [
    {
        "networkId": "",
        "ssid_num": "",
        "configurations": {
            "trafficShapingEnabled": True,
            "defaultRulesEnabled": True,
            "rules": [
                {
                    "definitions": [
                        {
                            "type": "host",
                            "value": "google.com"
                        },
                        {
                            "type": "port",
                            "value": "9090"
                        },
                        {
                            "type": "ipRange",
                            "value": "192.1.0.0"
                        },
                        {
                            "type": "ipRange",
                            "value": "192.1.0.0/16"
                        },
                        {
                            "type": "ipRange",
                            "value": "10.1.0.0/16:80"
                        },
                        {
                            "type": "localNet",
                            "value": "192.168.0.0/16"
                        }
                    ],
                    "perClientBandwidthLimits": {
                        "settings": "custom",
                        "bandwidthLimits": {
                            "limitUp": 1000000,
                            "limitDown": 1000000
                        }
                    },
                    "dscpTagValue": 0,
                    "pcpTagValue": 0
                }
            ]
        }
    }
]