import sys
sys.path.append('../../')
from config import *

list_snmp_nw = [
    {
        "networkId": ""
    }
]


update_snmp_nw = [
    {
        "networkId": "",
        "configurations": {
            "access": "users",
            "users": [
                {
                    "username": "AzureDiamond",
                    "passphrase": "hunter2"
                }
            ]
        }
        }
]