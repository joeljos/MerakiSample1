import sys
sys.path.append('../../')
from config import *

# Port Configuration

core_switch_config = [
    {
        "task": "General_Config", # Task key-value pair defines whether config is applied to a specific port or all ports.
        "exclude_portId": [1, 5, 6, 7, 17, 18], # portId is not a part of request body
        "configurations": {
            "name": "",
            "vlan": 1,
            "type": "trunk",
            "enabled": False
        }
    },
    {
        "task": "Specific_Config",
        "portId": [17, 18],
        "configurations": {
            "name": "Flexible Stacking Port",
            "enabled": True,
            "flexibleStackingEnabled": True
        }       
    },
    {
        "task": "Specific_Config", 
        "portId": [1], 
        "configurations": {
            "name": "VicSmart Router",
            "tags": ["VicSmart_Router"],
            "enabled": True,
            "type": "trunk",
            "vlan": 201,
            "allowedVlans": "100, 201, 102"
        }
    },
    {
        "task": "Specific_Config",
        "portId": [2],
        "configurations": {
            "name": "eduSTAR Server iDRAC",
            "tags": ["iDRAC"],
            "enabled": True,
            "type": "access",
            "vlan": 100
        }      
    },
        {
        "task": "Specific_Config",
        "portId": [3, 4],
        "configurations": {
            "name": "eduSTAR Server",
            "tags": ["eduSTAR_Server"],
            "enabled": True,
            "type": "trunk",
            "vlan": 1
        }      
    },
    {
        "task": "Specific_Config",
        "portId": [8],
        "configurations": {
            "name": "School Server",
            "tags": ["School_Server"],
            "enabled": True,
            "vlan": 1
        }       
    },
    {
        "task": "Specific_Config",
        "portId": [9, 10, 11, 12, 13, 14, 15, 16],
        "configurations": {
            "name": "Edge LACP Trunk",
            "tags": ["Uplinks"],
            "type": "trunk",
            "enabled": True,
            "vlan": 10
        }       
    }
]

edge_switch_config = [
    {
        "task": "General_Config", # Task key-value pair defines whether config is applied to a specific port or all ports.
        "exclude_portId": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 49, 50, 53, 54], # portId is not a part of request body
        "configurations": {
            "tags": [""],
            "name": "",
            "type": "access",
            "enabled": False,
            "vlan": 1
        }
    },
    {        
        "task": "Specific_Config", 
        "portId": [49, 50],                                      
        "configurations": {
            "name": "Uplinks to Core",
            "tags": ["Uplinks"],
            "enabled": True,
            "type": "trunk",
            "vlan": 10,
            "allowedVlans": "all"
        }
    },
    {       
        "task": "Specific_Config", 
        "portId": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],                                      
        "configurations": {
            "name": "eduSTAR Access Points",
            "tags": ["Access_Points"],
            "enabled": True,
            "poeEnabled": True,
            "type": "trunk",
            "vlan": 30,
            "allowedVlans": "all"
        }
    },
    {
        "task": "Specific_Config", 
        "portId": [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],                                      
        "configurations": {
            "name": "Peripherals",
            "tags": ["Peripherals"],
            "enabled": True,
            "poeEnabled": True,
            "type": "access",
            "vlan": 50
        }
    }
]