"""
Copyright (c) 2023 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

__author__ = "Lakshya Tyagi <ltyagi@cisco.com>, Trevor Maco <tmaco@cisco.com>"
__copyright__ = "Copyright (c) 2023 Cisco and/or its affiliates."
__license__ = "Cisco Sample Code License, Version 1.1"

import os
import re
import sys
import requests
import json
import logging
from dotenv import load_dotenv
from urllib.error import HTTPError


from configure_site.port_configurations.port_config import *

load_dotenv()

logging.basicConfig(level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')


meraki_base_url = os.getenv("MERAKI_BASE_URL")
meraki_api_key = os.getenv("MERAKI_API_KEY")
meraki_device_serial = os.getenv("MERAKI_DEVICE_SERIAL")

#header
headers = {
    'X-Cisco-Meraki-API-Key': meraki_api_key,
    'Content-Type': 'application/json'
}

def list_switch_ports(device_serial):
    """
    List ports for a meraki switch.
    """
    port_list = []
    try:
        response = requests.get(url = f"{meraki_base_url}/devices/{device_serial}/switch/ports", headers= headers)
        if response.status_code == 200:
            res = response.json()
            for port in res:
                port_dict = {}
                port_dict["portId"] = port["portId"]
                port_dict["name"] = port["name"]

                port_list.append(port_dict)

        else:
            print("list_switch_ports. API Call unsuccessful.")
    except HTTPError as http:
        print(http)
    except Exception as ex:
        print(ex)
    
    return port_list


def configure_switches(device_serial, switch_type):

    configuration_data = []
    if switch_type == "core_switch":
        configuration_data = core_switch_config
    elif switch_type == "edge_switch":
        configuration_data = edge_switch_config

    for config in configuration_data:

        # If configuration change is for a specific port
        if config["task"] == "Specific_Config":  
            config_portIds = config["portId"]
            config_payload = config["configurations"]
            for portIds in config_portIds:
                #logging.info(config_payload)
                
                try:
                    response = requests.request("PUT", url = f"{meraki_base_url}/devices/{device_serial}/switch/ports/{portIds}", headers=headers, data=json.dumps(config_payload))
                    if response.status_code == 200:
                        logging.info(f"Switch port configuration for port Id {portIds} completed.")
                except HTTPError as http:
                    logging.info(http)
                except Exception as ex:
                    logging.info(ex)
            
        # If configuration change is for all ports
        elif config["task"] == "General_Config":
            # Get list of all ports on the switch
            port_list = list_switch_ports(device_serial)
            # Get list of excluded ports for general configuration change
            excluded_ports = config["exclude_portId"]
            config_payload = config["configurations"]
            #logging.info(config_payload)

            for port in port_list:
                portId = port["portId"]
                if int(portId) not in excluded_ports:
                    # if port is not excluded, then make configuration update. 
                    try:
                        response = requests.request("PUT", url = f"{meraki_base_url}/devices/{device_serial}/switch/ports/{portId}", headers=headers, data=json.dumps(config_payload))
                        if response.status_code == 200:
                            logging.info(f"Switch port configuration for port Id {portId} completed.")
                    except HTTPError as http:
                        logging.info(http)
                    except Exception as ex:
                        logging.info(ex)
                        
                        
# configure_core_switches("Q2AP-MNHA-N44P")
                


