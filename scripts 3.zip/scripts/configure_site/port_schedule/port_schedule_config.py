import sys
sys.path.append('../../')
from config import *

create_port_schedule_config = [
    {
        "networkId": "",
        "configurations": {
            "name": "Weekdays schedule",
            "portSchedule": {
                "monday": {
                    "active": True,
                    "from": "9:00",
                    "to": "17:00"
                },
                "tuesday": {
                    "active": True,
                    "from": "9:00",
                    "to": "17:00"
                },
                "wednesday": {
                    "active": True,
                    "from": "9:00",
                    "to": "17:00"
                },
                "thursday": {
                    "active": True,
                    "from": "9:00",
                    "to": "17:00"
                },
                "friday": {
                    "active": True,
                    "from": "9:00",
                    "to": "17:00"
                },
                "saturday": {
                    "active": True,
                    "from": "0:00",
                    "to": "24:00"
                },
                "sunday": {
                    "active": True,
                    "from": "0:00",
                    "to": "24:00"
                }
            }
        }
    }
]