"""
Copyright (c) 2023 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

__author__ = "Lakshya Tyagi <ltyagi@cisco.com>"
__copyright__ = "Copyright (c) 2023 Cisco and/or its affiliates."
__license__ = "Cisco Sample Code License, Version 1.1"

import os
import re
import sys
import requests
import json
import logging
from dotenv import load_dotenv
from urllib.error import HTTPError


from configure_site.svi.svi_config import *

load_dotenv()

logging.basicConfig(level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')


meraki_base_url = os.getenv("MERAKI_BASE_URL")
meraki_api_key = os.getenv("MERAKI_API_KEY")


#header
headers = {
    'X-Cisco-Meraki-API-Key': meraki_api_key,
    'Content-Type': 'application/json'

}


# Get network switch stacks
# Create SVIs and DHCP 


def list_network_stacks(networkId):
    """
    List stack Ids for a network
    """
    try:
        response = requests.get(url = f"{meraki_base_url}/networks/{networkId}/switch/stacks", headers= headers)
        if response.status_code == 200:
            res = response.json()
            logging.info(f"List of stacks for Network ID {networkId} ")
            logging.info(res)
    except HTTPError as http:
        print(http)
    except Exception as ex:
        print(ex)



def create_svi():
    """
    Create Meraki SVI using Meraki API
    """

    for data in svi_data:
        svi_configuration = data["svi_configuration"]
        if "dhcp_configuration" in data:
            dhcp_configuration = data["dhcp_configuration"]

        try:
            response = requests.request("POST", url = f"{meraki_base_url}/networks/{meraki_network_id}/switch/stacks/{meraki_switch_stack_id}/routing/interfaces", headers=headers, data=json.dumps(svi_configuration))
            if response.status_code == 201:
                res = response.json()
                created_svi = res["name"]
                created_svi_id = res["interfaceId"]
                created_svi_vlan = res["vlanId"]
                logging.info(f"Successfully create SVI {created_svi} with ID {created_svi_id} in VLAN {created_svi_vlan}")

                # Configure DHCP (if applicable)
                if "dhcp_configuration" in data:
                    dhcp_response = requests.request("PUT", url = f"{meraki_base_url}/networks/{meraki_network_id}/switch/stacks/{meraki_switch_stack_id}/routing/interfaces/{created_svi_id}/dhcp", headers=headers, data=json.dumps(dhcp_configuration))
                    if dhcp_response.status_code == 200:
                        dhcp_res = dhcp_response.json()
                        logging.info(f"Added DHCP configuration for VLAN {created_svi_vlan}")
                        logging.info(dhcp_res)

        except HTTPError as http:
            logging.info(http)
        except Exception as ex:
            logging.info(ex)

            
