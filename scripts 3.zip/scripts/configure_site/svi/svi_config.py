import sys
sys.path.append('../../')
from config import *

# VLANs, Descriptions, SVIs

meraki_network_id = "L_813462682693800573"
meraki_switch_stack_id = "813462682693796368"

svi_data = [
    {
        "svi_configuration": {
            "vlanId": "10",
            "name": "eduSTAR-Devices",
            "interfaceIp": f"{net1020}.1",
            "subnet": convert_ip_to_subnet(f"{net1020}.1", "25"),
            "defaultGateway": f"{net1020}.1"  
        },
        "dhcp_configuration": {
            "dhcpMode": "dhcpServer",
            "dhcpLeaseTime": "1 day",
            "dnsNameserversOption": "custom",
            "dnsCustomNameservers": [ "8.8.8.8", "8.8.4.4" ],
            "bootOptionsEnabled": True,
            "bootNextServer": "1.2.3.4",
            "bootFileName": "home_boot_file",
            "dhcpOptions": [
                {
                        "code": "5",
                        "type": "text",
                        "value": "five"
                }
            ],
            "reservedIpRanges": [
                {
                        "start": f"{net1020}.1",
                        "end": f"{net1020}.10",
                        "comment": "A reserved IP range"
                }
            ],
            "fixedIpAssignments": [
                {
                        "mac": "22:33:44:55:66:77",
                        "name": "Cisco Meraki valued client",
                        "ip": f"{net1020}.11"
                }
            ]
        }
    },
    {
        "svi_configuration": {
            "vlanId": "20",
            "name": "Sch-Mgd-Servers",
            "interfaceIp": f"{net1020}.129",
            "subnet": convert_ip_to_subnet(f"{net1020}.129", "25")
        },
        "dhcp_configuration": {
            "dhcpMode": "dhcpServer",
            "dhcpLeaseTime": "1 day",
            "dnsNameserversOption": "custom",
            "dnsCustomNameservers": [ "8.8.8.8", "8.8.4.4" ],
            "bootOptionsEnabled": True,
            "bootNextServer": "1.2.3.4",
            "bootFileName": "home_boot_file",
            "dhcpOptions": [
                {
                    "code": "5",
                    "type": "text",
                    "value": "five"
                }
            ],
            "reservedIpRanges": [
                {
                    "start": f"{net1020}.129",
                    "end": f"{net1020}.139",
                    "comment": "A reserved IP range"
                }
            ],
            "fixedIpAssignments": [
                {
                    "mac": "22:33:44:55:66:77",
                    "name": "Cisco Meraki valued client",
                    "ip": f"{net1020}.140"
                }
            ]
        }
    },
    {
        "svi_configuration": {
            "vlanId": "30",
            "name": "eduSTAR-WAPs",
            "interfaceIp": f"{net30}.1",
            "subnet": convert_ip_to_subnet(f"{net30}.1", "24")
        },
        "dhcp_configuration": {
            "dhcpMode": "dhcpRelay",
            "dhcpRelayServerIps": [f"{net1020}.142"]
        }
        
    },
    {
        "svi_configuration": {
            "vlanId": "40",
            "name": "Sch-Mgd-General",
            "interfaceIp": f"{net40}.1",
            "subnet": convert_ip_to_subnet(f"{net40}.1", "24")
        },
        "dhcp_configuration": {
            "dhcpMode": "dhcpRelay",
            "dhcpRelayServerIps": [f"{net1020}.142"]
        }
        
    },
    {
        "svi_configuration": {
            "vlanId": "50",
            "name": "Sch-Mgd-Peripherals",
            "interfaceIp": f"{net50}.1",
            "subnet": convert_ip_to_subnet(f"{net50}.1", "24")
        },
        "dhcp_configuration": {
            "dhcpMode": "dhcpRelay",
            "dhcpRelayServerIps": [f"{net1020}.142"]
        }
    },
    {
        "svi_configuration": {
            "vlanId": "70",
            "name": "Dante-Audio",
            "interfaceIp": f"{net70}.1",
            "subnet": convert_ip_to_subnet(f"{net70}.1", "24")
        }
        
        
    }
]
