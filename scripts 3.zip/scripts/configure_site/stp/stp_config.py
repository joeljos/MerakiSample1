import sys
sys.path.append('../../')
from config import *

update_stp_config = [
    {
        "networkId": "L_813462682693800573",
        "configurations": {
            "rstpEnabled": True,
            "stpBridgePriority": [
                {
                    "stacks": [
                        "813462682693796368"
                    ],
                    "stpPriority": 4096
                }
            ]
        }
    }
]