import sys
sys.path.append('../../')
from config import *

"""
Configuration objects to update Meraki SSIDs
"""

ssid_config = [
    {
        "number": 0,
        "networkId": "L_813462682693800573",
        "configurations": {
            "name": "eduSTAR-Meraki",
            "enabled": True,
            "authMode": "8021x-radius",
            "encryptionMode": "wpa",
            "wpaEncryptionMode": "WPA2 only",
            "radiusServers": [
                {
                    "host": f"{net1020}.20",
                    "secret": "secret-string",
                    "port": 1812
                },
                {
                    "host": f"{net1020}.21",
                    "secret": "secret-string",
                    "port": 1812
                }
            ],
            "splashPage": "None",
            "mandatoryDhcpEnabled": True,
            "ipAssignmentMode": "Bridge mode",
            "defaultVlanId": 110,
            "lanIsolationEnabled": True,
            "radiusCoaEnabled": True,
            "useVlanTagging": True,
            "radiusOverride": True
        }
    },
    {
        "number": 1,
        "networkId": "L_813462682693800573",
        "configurations": {
            "name": " eduSTAR_Guest-Meraki",
            "enabled": True,
            "authMode": "open-with-radius",
            "radiusServers": [
                {
                    "host": "10.10.30.245",
                    "secret": "secret-string",
                    "port": 1812
                }
            ],
            "splashPage": "Cisco ISE",
            "walledGardenEnabled": True,
            "walledGardenRanges": ["10.10.30.245/32"],
            "mandatoryDhcpEnabled": True,
            "ipAssignmentMode": "Bridge mode",
            "defaultVlanId": 110,
            "lanIsolationEnabled": True,
            "radiusCoaEnabled": True,
            "useVlanTagging": True,
            "radiusOverride": False
        }
    }
]