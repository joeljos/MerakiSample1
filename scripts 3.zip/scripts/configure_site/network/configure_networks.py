"""
Copyright (c) 2023 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

__author__ = "Lakshya Tyagi <ltyagi@cisco.com>, Trevor Maco <tmaco@cisco.com>"
__copyright__ = "Copyright (c) 2023 Cisco and/or its affiliates."
__license__ = "Cisco Sample Code License, Version 1.1"

import os
import re
import sys
import requests
import logging
from dotenv import load_dotenv
from urllib.error import HTTPError
from configure_site.network.nw_config import update_nw_config
from configure_site.network.nw_config import create_nw_config
load_dotenv()

logging.basicConfig(level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')


meraki_base_url = os.getenv("MERAKI_BASE_URL")
meraki_api_key = os.getenv("MERAKI_API_KEY")
meraki_device_serial = os.getenv("MERAKI_DEVICE_SERIAL")

#header
headers = {
    'X-Cisco-Meraki-API-Key': meraki_api_key,
    'Content-Type': 'application/json'
}


# Create a network
# Update a network

def create_network():
    """
    Create a new network in an organization
    """

    for config in create_nw_config:
        org_id = config["orgId"]
        network_payload = config["configurations"]

        try:
            response = requests.request("POST", url = f"{meraki_base_url}/organizations/{org_id}/networks", headers= headers, data=network_payload)
            if response.status_code == 200:
                res = response.json()
                created_nw_name = res["name"]
                created_nw_id = res["id"]
                created_nw_org_id = res["organizationId"]
                logging.info(f"Created network with ID: {created_nw_id}, Name: {created_nw_name} in the organization: {created_nw_org_id}")
            else:
                failed_nw_name = config["configurations"]["name"]
                logging.info(f"Failed to create network {failed_nw_name}, please check configuration file.")
                continue
        except HTTPError as http:
            logging.info(http)
        except Exception as ex:
            logging.info(ex)
    

def update_network():
    """
    Update an existing network.
    """

    for config in update_nw_config:
        net_id = config["networkId"]
        network_update_payload = config["configurations"]

        try:
            response = requests.request("PUT", url = f"{meraki_base_url}/networks/{net_id}", headers= headers, data=network_update_payload)
            if response.status_code == 201:
                res = response.json()
                updated_nw_name = res["name"]
                updated_nw_id = res["id"]
                updated_org_id = res["organizationId"]
                logging.info(f"Created network with ID: {updated_nw_id}, Name: {updated_nw_name} in the organization: {updated_org_id}")
            else:
                failed_nw_name = config["configurations"]["name"]
                logging.info(f"Failed to create network {failed_nw_name}, please check configuration file.")
                continue
        except HTTPError as http:
            logging.info(http)
        except Exception as ex:
            logging.info(ex)


# create_network()
# update_network()