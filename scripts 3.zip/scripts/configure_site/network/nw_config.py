import sys
sys.path.append('../../')
from config import *

create_nw_config = [
    {
        "orgId": "",
        "configurations": {
            "name": "Main Office",
            "productTypes": [
                "appliance",
                "switch",
                "wireless"
            ],
            "tags": [ "tag1", "tag2" ],
            "timeZone": "America/Los_Angeles",
            "copyFromNetworkId": "N_24329156",
            "notes": "Additional description of the network"
        }
    }
]

update_nw_config = [
    {
        "networkId": "",
        "configurations": {
            "name": "Main Office",
            "timeZone": "America/Los_Angeles",
            "tags": [ "tag1", "tag2" ],
            "enrollmentString": "my-enrollment-string",
            "notes": "Additional description of the network"
        }
    }
]